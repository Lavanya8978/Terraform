def lambda_handler(event, context):
    return {"statusCode": 200, "body": "Lamda code into S3 Bucket"}